/*
SQLyog - Free MySQL GUI v5.0
Host - 5.0.16-nt : Database - medicaldocument
*********************************************************************
Server version : 5.0.16-nt
*/


create database if not exists `medicaldocument`;

USE `medicaldocument`;

/*Table structure for table `cloudserveraction` */

DROP TABLE IF EXISTS `cloudserveraction`;

CREATE TABLE `cloudserveraction` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `doctorregmedicine` */

DROP TABLE IF EXISTS `doctorregmedicine`;

CREATE TABLE `doctorregmedicine` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `mobile` varchar(80) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `status` varchar(80) NOT NULL,
  `accesskey` varchar(80) NOT NULL,
  `hsptlname` varchar(80) NOT NULL,
  `department` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `hospitals` */

DROP TABLE IF EXISTS `hospitals`;

CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(500) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `hspencrypt` */

DROP TABLE IF EXISTS `hspencrypt`;

CREATE TABLE `hspencrypt` (
  `id` int(11) NOT NULL auto_increment,
  `pname` varchar(100) NOT NULL,
  `reportname` varchar(100) NOT NULL,
  `edisease` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `bgp` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `hname` varchar(100) NOT NULL,
  `doctorname` varchar(100) NOT NULL,
  `contents` longtext NOT NULL,
  `trapdoorkey` varchar(500) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `patientregistration` */

DROP TABLE IF EXISTS `patientregistration`;

CREATE TABLE `patientregistration` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(80) NOT NULL,
  `lname` varchar(80) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(80) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL,
  `accesskey` varchar(100) NOT NULL,
  `profilepic` longblob NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `patientschedule` */

DROP TABLE IF EXISTS `patientschedule`;

CREATE TABLE `patientschedule` (
  `id` int(11) NOT NULL auto_increment,
  `patientname` varchar(80) NOT NULL,
  `pidfromhspenc` varchar(80) NOT NULL,
  `patientemail` varchar(80) NOT NULL,
  `docName` varchar(80) NOT NULL,
  `doctorEmail` varchar(80) NOT NULL,
  `hsptlname` varchar(80) NOT NULL,
  `treatmentdate` varchar(80) NOT NULL,
  `status` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `transactions` */

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL auto_increment,
  `trnxID` int(11) default NULL,
  `treatementid` int(11) default NULL,
  `doctorname` varchar(80) NOT NULL,
  `patientemail` varchar(80) NOT NULL,
  `hsptlname` varchar(80) NOT NULL,
  `paidamount` varchar(80) NOT NULL,
  `nameoncard` varchar(80) NOT NULL,
  `creaditcardnumber` varchar(80) NOT NULL,
  `expirecard` varchar(80) NOT NULL,
  `cvv` varchar(80) NOT NULL,
  `cdate` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `treatmentdetails` */

DROP TABLE IF EXISTS `treatmentdetails`;

CREATE TABLE `treatmentdetails` (
  `id` int(11) NOT NULL auto_increment,
  `docName` varchar(80) NOT NULL,
  `doctorEmail` varchar(80) NOT NULL,
  `pid` int(11) default NULL,
  `patientemail` varchar(80) NOT NULL,
  `disease` varchar(80) NOT NULL,
  `hsptlname` varchar(80) NOT NULL,
  `treatment` varchar(500) NOT NULL,
  `cdate` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `paymentstatus` varchar(50) default 'waiting',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `pid` (`pid`,`cdate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

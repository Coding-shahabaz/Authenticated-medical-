/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medicaldocument.util;

import com.medicaldocument.db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Ch.Sravani
 */
public class PatientUtility {
    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public int checkPatientEmail(String email){
    Integer patientid = 0;
    Map<String,Integer> map = getAllPatientEmail();
        //System.out.println("Map is "+map);
    boolean rslt = map.containsKey(email);
    if(rslt==true){
    patientid = map.get(email);
       // System.out.println("PPP ID is "+patientid);
    }else{
    patientid = 0;
    }
        return patientid;
    }
    
    public Map<String,Integer> getAllPatientEmail(){
    Map<String,Integer> map = new HashMap<>();
        try {
            con = DBConnection.getConnection();
            String sqlQuery = "select id,email from hspencrypt";
            ps = con.prepareStatement(sqlQuery);
            rs = ps.executeQuery();
            while(rs.next()){
            String email = rs.getString("email");
            int id = rs.getInt("id");
            map.put(EncryptionAlgoritham.decrypt(email), id);
            }
        } catch (Exception e) {
            System.out.println("Error at getting All Emails "+e.getMessage());
        }finally{
            try {
                rs.close();
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
        return map;
    }
    public void updatePatientTreatMentSchedule(int pid,String schedule){
        try {
            con = DBConnection.getConnection();
            String sqlQuery = "update hspencrypt set status=? where id = ?";
            ps = con.prepareStatement(sqlQuery);
            ps.setString(1, schedule);
            ps.setInt(2, pid);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error at Updating PatientSchedule "+e.getMessage());
        }finally{
            try {
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
    }
    
     public String getPatientDisease(int pid){
         String disease = null;
        try {
            con = DBConnection.getConnection();
            String sqlQuery = "select edisease from  hspencrypt where id = ?";
            ps = con.prepareStatement(sqlQuery);
            ps.setInt(1, pid);           
            rs =ps.executeQuery();
            if(rs.next()){
            disease = EncryptionAlgoritham.decrypt(rs.getString("edisease"));
            }
            
        } catch (Exception e) {
            System.out.println("Getting patient Disease  "+e.getMessage());
        }finally{
            try {
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
        return disease;
    }
     public void updatePaymentStatus(int treatmentId){
         String sts = "payment done";
         try {
             con = DBConnection.getConnection();
             String sql = "update treatmentdetails set paymentstatus = ? where id=?";
             ps = con.prepareStatement(sql);
             ps.setString(1, sts);
             ps.setInt(2, treatmentId);
             ps.executeUpdate();
         } catch (Exception e) {
             System.out.println("Error at Update Transactions "+e.getMessage());
         }finally{
             try {
                 ps.close();
                 con.close();
             } catch (Exception e) {
             }
         }
     }
     
      public boolean getTreatmentDoneorNot(int pid,String patientemail,String disease,String hsptlname){
         boolean flag = false;
        try {
            con = DBConnection.getConnection();
            String sqlQuery = "select count(*) from  treatmentdetails where pid = ? and patientemail = ? and disease = ? and hsptlname = ?";
            System.out.println("Sql Query = "+sqlQuery);
            ps = con.prepareStatement(sqlQuery);
            ps.setInt(1, pid);           
            ps.setString(2, patientemail);
            ps.setString(3, disease);
            ps.setString(4, hsptlname);
            rs =ps.executeQuery();
            if(rs.next()){
                int no = rs.getInt(1);
                if(no>0){
                flag = true;
                }else{
                flag = false;
                }
            //flag = true;
            }else{
            //flag = false;
            }
            
        } catch (Exception e) {
            System.out.println("Getting patient Disease  "+e.getMessage());
        }finally{
            try {
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
        return flag;
    } 
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medicaldocument.actions;

import com.medicaldocument.db.DBConnection;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author Ch.Sravani
 */
@MultipartConfig
public class PatientRegisterAction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String email = request.getParameter("email");
        String pswd = request.getParameter("pswd");
        String mobile = request.getParameter("mobile");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String address = request.getParameter("address");
        Part filePart = request.getPart("pic");
        InputStream is = filePart.getInputStream();
        String status = "waiting";
        String accesskey = "notgenerated";
        
        Connection con = null;
        PreparedStatement ps = null;
        try {
            con = DBConnection.getConnection();
            String sqlQuery = "insert into patientregistration(fname,lname,email,password,mobile,dob,gender,address,status,accesskey,profilepic) values(?,?,?,?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(sqlQuery);
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, email);
            ps.setString(4, pswd);
            ps.setString(5, mobile);
            ps.setString(6, dob);
            ps.setString(7, gender);
            ps.setString(8, address);
            ps.setString(9, status);
            ps.setString(10, accesskey);
            ps.setBinaryStream(11, is);
            int no = ps.executeUpdate();
            if(no>0){
            response.sendRedirect("PatientRegistration.jsp?msg=success");
            }else{
            response.sendRedirect("PatientRegistration.jsp?msg=failed");
            }
            
            
        } catch (IOException | SQLException e) {
            response.sendRedirect("PatientRegistration.jsp?msg=exist");
        } finally {
            try {
                ps.close();
                con.close();
            } catch (SQLException e) {
            }
        }

    }
        
    /**
     *
     * @return
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    

}
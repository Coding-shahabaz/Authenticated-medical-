/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.medicaldocument.actions;

import com.medicaldocument.db.DBConnection;
import com.medicaldocument.util.PatientUtility;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ch.Sravani
 */
public class PatientMakingPayementAction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession hs = request.getSession();
        String fname = hs.getAttribute("fname").toString();
        Random r = new Random();
        
        int trnxID = 100000 + (int)(r.nextFloat() * 899900);
        int treatementid = Integer.parseInt(request.getParameter("treatmentid"));
        String doctorname = request.getParameter("doctorname");
        String patientemail = request.getParameter("patientemail");
        String hsptlname = request.getParameter("hsptlname");
        String paidamount = request.getParameter("paidamount");
        String nameoncard = request.getParameter("nameoncard");
        String creaditcardnumber = request.getParameter("creaditcardnumber");
        String expireMM = request.getParameter("expireMM");
        String expireYY = request.getParameter("expireYY");
        String exprDate = expireMM+"/"+expireYY;
        String cvv = request.getParameter("cvv");        
        java.sql.Date cdate = new java.sql.Date(new java.util.Date().getTime());
        
        Connection con = null;        
        PreparedStatement ps = null;               
        
        PatientUtility pu = new PatientUtility();
        try {
             con = DBConnection.getConnection();
            String sqlQuery = "insert into transactions(trnxID,treatementid,doctorname,patientemail,hsptlname,paidamount,nameoncard,creaditcardnumber,expirecard,cvv,cdate)values(?,?,?,?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(sqlQuery);
            ps.setInt(1, trnxID);
            ps.setInt(2, treatementid);
            ps.setString(3, doctorname);
            ps.setString(4, patientemail);
            ps.setString(5, hsptlname);   
            ps.setString(6, paidamount);
            ps.setString(7, nameoncard);
            ps.setString(8, creaditcardnumber);
            ps.setString(9, exprDate);           
            ps.setString(10, cvv);
            ps.setDate(11, cdate);
            int no = ps.executeUpdate();
            if(no>0){
            pu.updatePaymentStatus(treatementid);
            response.sendRedirect("PatientMakePayement.jsp?msg=payment Done");
            }else{
            response.sendRedirect("PatientMakePayement.jsp?msg=payment failed");
            }
                 
                   
            
        }catch(Exception ex){
            System.out.println("Error at Transaction "+ex.getMessage());
        }finally{
            try {
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
